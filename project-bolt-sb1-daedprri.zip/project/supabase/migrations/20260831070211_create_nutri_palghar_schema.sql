/*
# Nutri Palghar — Core Schema

## Purpose
Stores family member profiles, 24-hour food recall entries, and 7-day diet plans
for the Nutri Palghar nutrition app. Single-tenant (no sign-in) — all data is
shared across the anon-key client.

## New Tables
1. `profiles` — family members (name, age, gender, weight, height, activity level, life-stage group)
2. `food_recall` — 24-hour food recall entries linked to a profile (food name, meal, quantity, date)
3. `diet_plans` — 7-day diet plans linked to a profile (day 1-7, meals, notes)

## Security
- RLS enabled on all tables.
- Anon + authenticated can CRUD all data (single-tenant, intentionally shared).
*/

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  age integer NOT NULL,
  gender text NOT NULL CHECK (gender IN ('male', 'female')),
  weight_kg numeric NOT NULL,
  height_cm numeric NOT NULL,
  activity_level text NOT NULL DEFAULT 'moderate' CHECK (activity_level IN ('sedentary', 'light', 'moderate', 'active', 'very_active')),
  life_stage text NOT NULL DEFAULT 'adult' CHECK (life_stage IN ('child', 'adolescent', 'adult', 'pregnant', 'lactating', 'elderly')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_profiles" ON profiles;
CREATE POLICY "anon_select_profiles" ON profiles FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_profiles" ON profiles;
CREATE POLICY "anon_insert_profiles" ON profiles FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_profiles" ON profiles;
CREATE POLICY "anon_update_profiles" ON profiles FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_profiles" ON profiles;
CREATE POLICY "anon_delete_profiles" ON profiles FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS food_recall (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  food_name text NOT NULL,
  meal_type text NOT NULL CHECK (meal_type IN ('breakfast', 'lunch', 'snack', 'dinner')),
  quantity text NOT NULL,
  recall_date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE food_recall ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_food_recall" ON food_recall;
CREATE POLICY "anon_select_food_recall" ON food_recall FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_food_recall" ON food_recall;
CREATE POLICY "anon_insert_food_recall" ON food_recall FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_food_recall" ON food_recall;
CREATE POLICY "anon_update_food_recall" ON food_recall FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_food_recall" ON food_recall;
CREATE POLICY "anon_delete_food_recall" ON food_recall FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS diet_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  day_number integer NOT NULL CHECK (day_number BETWEEN 1 AND 7),
  breakfast text,
  lunch text,
  snack text,
  dinner text,
  notes text,
  created_at timestamptz DEFAULT now(),
  UNIQUE (profile_id, day_number)
);

ALTER TABLE diet_plans ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_diet_plans" ON diet_plans;
CREATE POLICY "anon_select_diet_plans" ON diet_plans FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_diet_plans" ON diet_plans;
CREATE POLICY "anon_insert_diet_plans" ON diet_plans FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_diet_plans" ON diet_plans;
CREATE POLICY "anon_update_diet_plans" ON diet_plans FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_diet_plans" ON diet_plans;
CREATE POLICY "anon_delete_diet_plans" ON diet_plans FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_food_recall_profile ON food_recall(profile_id);
CREATE INDEX IF NOT EXISTS idx_diet_plans_profile ON diet_plans(profile_id);
