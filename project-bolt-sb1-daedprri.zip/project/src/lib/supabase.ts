import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Profile = {
  id: string;
  name: string;
  age: number;
  gender: "male" | "female";
  weight_kg: number;
  height_cm: number;
  activity_level: "sedentary" | "light" | "moderate" | "active" | "very_active";
  life_stage: "child" | "adolescent" | "adult" | "pregnant" | "lactating" | "elderly";
  created_at: string;
};

export type FoodRecall = {
  id: string;
  profile_id: string;
  food_name: string;
  meal_type: "breakfast" | "lunch" | "snack" | "dinner";
  quantity: string;
  recall_date: string;
  created_at: string;
};

export type DietPlan = {
  id: string;
  profile_id: string;
  day_number: number;
  breakfast: string | null;
  lunch: string | null;
  snack: string | null;
  dinner: string | null;
  notes: string | null;
  created_at: string;
};
