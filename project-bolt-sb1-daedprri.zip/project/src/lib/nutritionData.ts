// Nutrition database for common Indian / Maharashtrian foods.
// Values are per 100g (energy in kcal, nutrients in mg or mcg as noted).
// Sources: ICMR-NIN "Nutritive Value of Indian Foods", IFCT 2017, USDA approximations.

export type FoodItem = {
  id: string;
  name: string;
  name_mr: string;
  name_hi: string;
  category: "cereal" | "pulse" | "vegetable" | "fruit" | "dairy" | "meat" | "fat" | "spice" | "other";
  energy_kcal: number;
  protein_g: number;
  carbs_g: number;
  fat_g: number;
  fiber_g: number;
  iron_mg: number;
  calcium_mg: number;
  vitamin_a_mcg: number;
  vitamin_c_mg: number;
  // default serving size in grams for quick-add
  default_serving_g: number;
};

export const FOOD_DATABASE: FoodItem[] = [
  // Cereals
  { id: "rice", name: "Rice (cooked)", name_mr: "भात", name_hi: "चावल", category: "cereal", energy_kcal: 130, protein_g: 2.7, carbs_g: 28, fat_g: 0.3, fiber_g: 0.4, iron_mg: 0.2, calcium_mg: 10, vitamin_a_mcg: 0, vitamin_c_mg: 0, default_serving_g: 200 },
  { id: "bhakri", name: "Jowar Bhakri", name_mr: "ज्वारी भाकरी", name_hi: "ज्वार रोटी", category: "cereal", energy_kcal: 349, protein_g: 10.4, carbs_g: 72, fat_g: 1.9, fiber_g: 9.7, iron_mg: 4.1, calcium_mg: 36, vitamin_a_mcg: 0, vitamin_c_mg: 0, default_serving_g: 120 },
  { id: "chapati", name: "Wheat Chapati", name_mr: "चपाती", name_hi: "रोटी", category: "cereal", energy_kcal: 297, protein_g: 11, carbs_g: 60, fat_g: 2.5, fiber_g: 4.9, iron_mg: 3.6, calcium_mg: 38, vitamin_a_mcg: 0, vitamin_c_mg: 0, default_serving_g: 80 },
  { id: "rice_flakes", name: "Poha (Rice Flakes)", name_mr: "पोहे", name_hi: "पोहा", category: "cereal", energy_kcal: 346, protein_g: 6.6, carbs_g: 77, fat_g: 1.1, fiber_g: 2.5, iron_mg: 6.6, calcium_mg: 20, vitamin_a_mcg: 0, vitamin_c_mg: 0, default_serving_g: 150 },
  { id: "ragi", name: "Ragi (Finger Millet)", name_mr: "नाचणी", name_hi: "रागी", category: "cereal", energy_kcal: 336, protein_g: 7.3, carbs_g: 72, fat_g: 1.3, fiber_g: 11.2, iron_mg: 3.9, calcium_mg: 344, vitamin_a_mcg: 0, vitamin_c_mg: 0, default_serving_g: 100 },
  { id: "upma", name: "Upma (Rava)", name_mr: "उपमा", name_hi: "उपमा", category: "cereal", energy_kcal: 180, protein_g: 4, carbs_g: 30, fat_g: 4, fiber_g: 1.5, iron_mg: 0.8, calcium_mg: 12, vitamin_a_mcg: 5, vitamin_c_mg: 0, default_serving_g: 200 },

  // Pulses
  { id: "dal", name: "Toor Dal (cooked)", name_mr: "तूर डाळ", name_hi: "अरहर दाल", category: "pulse", energy_kcal: 87, protein_g: 4.8, carbs_g: 15, fat_g: 0.5, fiber_g: 3.1, iron_mg: 1.2, calcium_mg: 18, vitamin_a_mcg: 0, vitamin_c_mg: 0, default_serving_g: 150 },
  { id: "moong", name: "Moong Dal (cooked)", name_mr: "मूग डाळ", name_hi: "मूंग दाल", category: "pulse", energy_kcal: 91, protein_g: 5.5, carbs_g: 15, fat_g: 0.4, fiber_g: 2.5, iron_mg: 1.4, calcium_mg: 25, vitamin_a_mcg: 0, vitamin_c_mg: 0, default_serving_g: 150 },
  { id: "chana", name: "Chana (Bengal Gram, cooked)", name_mr: "चणा", name_hi: "चना", category: "pulse", energy_kcal: 164, protein_g: 8.9, carbs_g: 27, fat_g: 2.6, fiber_g: 7.6, iron_mg: 2.9, calcium_mg: 49, vitamin_a_mcg: 6, vitamin_c_mg: 1, default_serving_g: 150 },
  { id: "soyabean", name: "Soyabean (cooked)", name_mr: "सोयाबीन", name_hi: "सोयाबीन", category: "pulse", energy_kcal: 173, protein_g: 17, carbs_g: 9, fat_g: 9, fiber_g: 6, iron_mg: 5, calcium_mg: 197, vitamin_a_mcg: 1, vitamin_c_mg: 0, default_serving_g: 100 },

  // Vegetables
  { id: "spinach", name: "Spinach (Palak)", name_mr: "पालक", name_hi: "पालक", category: "vegetable", energy_kcal: 26, protein_g: 2.9, carbs_g: 2.8, fat_g: 0.4, fiber_g: 2.2, iron_mg: 1.5, calcium_mg: 73, vitamin_a_mcg: 314, vitamin_c_mg: 28, default_serving_g: 100 },
  { id: "amaranth", name: "Amaranth Leaves (Chaulai)", name_mr: "चौळई", name_hi: "चौलाई", category: "vegetable", energy_kcal: 23, protein_g: 2.5, carbs_g: 3.2, fat_g: 0.3, fiber_g: 2.8, iron_mg: 2.1, calcium_mg: 160, vitamin_a_mcg: 292, vitamin_c_mg: 22, default_serving_g: 100 },
  { id: "drumstick", name: "Drumstick (Shevga)", name_mr: "शेवगा", name_hi: "सहजन", category: "vegetable", energy_kcal: 64, protein_g: 2.5, carbs_g: 13, fat_g: 0.7, fiber_g: 3.2, iron_mg: 0.6, calcium_mg: 30, vitamin_a_mcg: 4, vitamin_c_mg: 51, default_serving_g: 100 },
  { id: "bhendi", name: "Okra (Bhendi)", name_mr: "भेंडी", name_hi: "भिंडी", category: "vegetable", energy_kcal: 33, protein_g: 1.9, carbs_g: 7.5, fat_g: 0.2, fiber_g: 3.2, iron_mg: 0.6, calcium_mg: 82, vitamin_a_mcg: 36, vitamin_c_mg: 21, default_serving_g: 100 },
  { id: "tomato", name: "Tomato", name_mr: "टोमॅटो", name_hi: "टमाटर", category: "vegetable", energy_kcal: 18, protein_g: 0.9, carbs_g: 3.9, fat_g: 0.2, fiber_g: 1.2, iron_mg: 0.3, calcium_mg: 10, vitamin_a_mcg: 42, vitamin_c_mg: 14, default_serving_g: 100 },
  { id: "carrot", name: "Carrot", name_mr: "गाजर", name_hi: "गाजर", category: "vegetable", energy_kcal: 41, protein_g: 0.9, carbs_g: 9.6, fat_g: 0.2, fiber_g: 2.8, iron_mg: 0.5, calcium_mg: 33, vitamin_a_mcg: 835, vitamin_c_mg: 6, default_serving_g: 100 },
  { id: "potato", name: "Potato", name_mr: "बटाटा", name_hi: "आलू", category: "vegetable", energy_kcal: 77, protein_g: 2, carbs_g: 17, fat_g: 0.1, fiber_g: 2.2, iron_mg: 0.8, calcium_mg: 12, vitamin_a_mcg: 0, vitamin_c_mg: 20, default_serving_g: 150 },
  { id: "onion", name: "Onion", name_mr: "कांदा", name_hi: "प्याज", category: "vegetable", energy_kcal: 40, protein_g: 1.1, carbs_g: 9.3, fat_g: 0.1, fiber_g: 1.7, iron_mg: 0.2, calcium_mg: 23, vitamin_a_mcg: 0, vitamin_c_mg: 7, default_serving_g: 80 },
  { id: "curry_leaves", name: "Curry Leaves (Kadi Patta)", name_mr: "कढीपत्ता", name_hi: "करी पत्ता", category: "vegetable", energy_kcal: 108, protein_g: 6.1, carbs_g: 18, fat_g: 1.1, fiber_g: 6.4, iron_mg: 1.9, calcium_mg: 147, vitamin_a_mcg: 306, vitamin_c_mg: 4, default_serving_g: 10 },

  // Fruits
  { id: "banana", name: "Banana", name_mr: "केळी", name_hi: "केला", category: "fruit", energy_kcal: 89, protein_g: 1.1, carbs_g: 23, fat_g: 0.3, fiber_g: 2.6, iron_mg: 0.3, calcium_mg: 5, vitamin_a_mcg: 3, vitamin_c_mg: 9, default_serving_g: 120 },
  { id: "guava", name: "Guava (Peru)", name_mr: "पेरू", name_hi: "अमरूद", category: "fruit", energy_kcal: 68, protein_g: 2.6, carbs_g: 14, fat_g: 1, fiber_g: 5.4, iron_mg: 0.3, calcium_mg: 18, vitamin_a_mcg: 12, vitamin_c_mg: 228, default_serving_g: 100 },
  { id: "mango", name: "Mango (Local)", name_mr: "आंबा", name_hi: "आम", category: "fruit", energy_kcal: 60, protein_g: 0.8, carbs_g: 15, fat_g: 0.4, fiber_g: 1.6, iron_mg: 0.2, calcium_mg: 11, vitamin_a_mcg: 54, vitamin_c_mg: 36, default_serving_g: 150 },
  { id: "papaya", name: "Papaya (Papai)", name_mr: "पपई", name_hi: "पपीता", category: "fruit", energy_kcal: 43, protein_g: 0.5, carbs_g: 11, fat_g: 0.3, fiber_g: 1.7, iron_mg: 0.3, calcium_mg: 20, vitamin_a_mcg: 47, vitamin_c_mg: 62, default_serving_g: 150 },
  { id: "lemon", name: "Lemon (Nimbu)", name_mr: "लिंबू", name_hi: "नींबू", category: "fruit", energy_kcal: 29, protein_g: 1.1, carbs_g: 9.3, fat_g: 0.3, fiber_g: 2.8, iron_mg: 0.6, calcium_mg: 26, vitamin_a_mcg: 1, vitamin_c_mg: 53, default_serving_g: 30 },
  { id: "sitafal", name: "Custard Apple (Sitafal)", name_mr: "सिताफळ", name_hi: "शरीफा", category: "fruit", energy_kcal: 101, protein_g: 1.7, carbs_g: 25, fat_g: 0.6, fiber_g: 3.4, iron_mg: 0.7, calcium_mg: 17, vitamin_a_mcg: 0, vitamin_c_mg: 36, default_serving_g: 100 },

  // Dairy
  { id: "milk", name: "Cow Milk", name_mr: "गाईचे दूध", name_hi: "गाय का दूध", category: "dairy", energy_kcal: 67, protein_g: 3.2, carbs_g: 5, fat_g: 3.6, fiber_g: 0, iron_mg: 0.1, calcium_mg: 120, vitamin_a_mcg: 52, vitamin_c_mg: 0, default_serving_g: 200 },
  { id: "buttermilk", name: "Buttermilk (Tak)", name_mr: "ताक", name_hi: "छाछ", category: "dairy", energy_kcal: 40, protein_g: 2, carbs_g: 4, fat_g: 1.5, fiber_g: 0, iron_mg: 0.1, calcium_mg: 50, vitamin_a_mcg: 20, vitamin_c_mg: 0, default_serving_g: 200 },
  { id: "paneer", name: "Paneer", name_mr: "पनीर", name_hi: "पनीर", category: "dairy", energy_kcal: 265, protein_g: 18, carbs_g: 1.2, fat_g: 20, fiber_g: 0, iron_mg: 0.4, calcium_mg: 208, vitamin_a_mcg: 96, vitamin_c_mg: 0, default_serving_g: 80 },
  { id: "curd", name: "Curd (Dahi)", name_mr: "दही", name_hi: "दही", category: "dairy", energy_kcal: 98, protein_g: 4.3, carbs_g: 5, fat_g: 6, fiber_g: 0, iron_mg: 0.2, calcium_mg: 150, vitamin_a_mcg: 26, vitamin_c_mg: 0, default_serving_g: 100 },

  // Meat / Fish / Egg
  { id: "egg", name: "Egg", name_mr: "अंडे", name_hi: "अंडा", category: "meat", energy_kcal: 155, protein_g: 13, carbs_g: 1.1, fat_g: 11, fiber_g: 0, iron_mg: 2.7, calcium_mg: 50, vitamin_a_mcg: 237, vitamin_c_mg: 0, default_serving_g: 60 },
  { id: "chicken", name: "Chicken (cooked)", name_mr: "कोंबडी", name_hi: "चिकन", category: "meat", energy_kcal: 165, protein_g: 31, carbs_g: 0, fat_g: 3.6, fiber_g: 0, iron_mg: 1.3, calcium_mg: 15, vitamin_a_mcg: 6, vitamin_c_mg: 0, default_serving_g: 150 },
  { id: "fish", name: "Fish (local, cooked)", name_mr: "मासा", name_hi: "मछली", category: "meat", energy_kcal: 206, protein_g: 22, carbs_g: 0, fat_g: 12, fiber_g: 0, iron_mg: 2.5, calcium_mg: 20, vitamin_a_mcg: 15, vitamin_c_mg: 0, default_serving_g: 150 },

  // Fats / Nuts
  { id: "groundnut", name: "Groundnut (Peanut)", name_mr: "भुईमूग", name_hi: "मूंगफली", category: "fat", energy_kcal: 567, protein_g: 26, carbs_g: 16, fat_g: 49, fiber_g: 8.5, iron_mg: 4.6, calcium_mg: 92, vitamin_a_mcg: 0, vitamin_c_mg: 0, default_serving_g: 30 },
  { id: "ghee", name: "Ghee", name_mr: "तूप", name_hi: "घी", category: "fat", energy_kcal: 900, protein_g: 0, carbs_g: 0, fat_g: 100, fiber_g: 0, iron_mg: 0, calcium_mg: 0, vitamin_a_mcg: 300, vitamin_c_mg: 0, default_serving_g: 10 },
  { id: "oil", name: "Cooking Oil", name_mr: "तेल", name_hi: "तेल", category: "fat", energy_kcal: 884, protein_g: 0, carbs_g: 0, fat_g: 100, fiber_g: 0, iron_mg: 0, calcium_mg: 0, vitamin_a_mcg: 0, vitamin_c_mg: 0, default_serving_g: 10 },
  { id: "coconut", name: "Coconut (fresh)", name_mr: "नारळ", name_hi: "नारियल", category: "fat", energy_kcal: 354, protein_g: 3.3, carbs_g: 15, fat_g: 33, fiber_g: 9, iron_mg: 2.4, calcium_mg: 14, vitamin_a_mcg: 0, vitamin_c_mg: 3, default_serving_g: 30 },

  // Other
  { id: "jaggery", name: "Jaggery (Gul)", name_mr: "गूळ", name_hi: "गुड़", category: "other", energy_kcal: 383, protein_g: 0.4, carbs_g: 98, fat_g: 0.1, fiber_g: 0.1, iron_mg: 11, calcium_mg: 80, vitamin_a_mcg: 0, vitamin_c_mg: 0, default_serving_g: 20 },
  { id: "sugar", name: "Sugar", name_mr: "साखर", name_hi: "चीनी", category: "other", energy_kcal: 387, protein_g: 0, carbs_g: 100, fat_g: 0, fiber_g: 0, iron_mg: 0, calcium_mg: 0, vitamin_a_mcg: 0, vitamin_c_mg: 0, default_serving_g: 10 },
  { id: "tea", name: "Tea (with milk)", name_mr: "चहा", name_hi: "चाय", category: "other", energy_kcal: 50, protein_g: 1.5, carbs_g: 6, fat_g: 1.5, fiber_g: 0, iron_mg: 0.2, calcium_mg: 30, vitamin_a_mcg: 10, vitamin_c_mg: 0, default_serving_g: 150 },
];

// Recommended Dietary Allowances (ICMR-NIN 2020) per day, by life-stage + gender
export type RDA = {
  energy_kcal: number;
  protein_g: number;
  iron_mg: number;
  calcium_mg: number;
  vitamin_a_mcg: number;
  vitamin_c_mg: number;
  fiber_g: number;
};

export function getRDA(lifeStage: string, gender: string, _age: number, activity: string): RDA {
  const actFactor: Record<string, number> = {
    sedentary: 1.0,
    light: 1.12,
    moderate: 1.25,
    active: 1.48,
    very_active: 1.7,
  };
  const factor = actFactor[activity] ?? 1.25;

  // Base energy by life stage
  let baseEnergy = 2000;
  let protein = 45;
  let iron = 17;
  let calcium = 1000;
  let vitA = 1000;
  let vitC = 40;
  let fiber = 30;

  if (lifeStage === "child") {
    baseEnergy = 1100;
    protein = 12;
    iron = 8;
    calcium = 600;
    vitA = 400;
    vitC = 25;
    fiber = 15;
  } else if (lifeStage === "adolescent") {
    baseEnergy = 2400;
    protein = 40;
    iron = gender === "female" ? 27 : 22;
    calcium = 800;
    vitA = 600;
    vitC = 40;
    fiber = 25;
  } else if (lifeStage === "adult") {
    baseEnergy = gender === "male" ? 2320 : 1900;
    protein = gender === "male" ? 54 : 46;
    iron = gender === "female" ? 28 : 17;
    calcium = 1000;
    vitA = 1000;
    vitC = 40;
    fiber = 30;
  } else if (lifeStage === "pregnant") {
    baseEnergy = 2250;
    protein = 60;
    iron = 40;
    calcium = 1000;
    vitA = 1000;
    vitC = 50;
    fiber = 30;
  } else if (lifeStage === "lactating") {
    baseEnergy = 2500;
    protein = 68;
    iron = 23;
    calcium = 1200;
    vitA = 1100;
    vitC = 60;
    fiber = 30;
  } else if (lifeStage === "elderly") {
    baseEnergy = 1800;
    protein = 48;
    iron = 17;
    calcium = 1200;
    vitA = 1000;
    vitC = 50;
    fiber = 30;
  }

  return {
    energy_kcal: Math.round(baseEnergy * factor),
    protein_g: protein,
    iron_mg: iron,
    calcium_mg: calcium,
    vitamin_a_mcg: vitA,
    vitamin_c_mg: vitC,
    fiber_g: fiber,
  };
}

// Local Maharashtra food recommendations by nutrient deficiency
export type Recommendation = {
  nutrient: string;
  nutrient_mr: string;
  nutrient_hi: string;
  foods: { name: string; name_mr: string; name_hi: string }[];
  tip: string;
  tip_mr: string;
  tip_hi: string;
};

export const RECOMMENDATIONS: Recommendation[] = [
  {
    nutrient: "Iron",
    nutrient_mr: "लोह",
    nutrient_hi: "आयरन",
    foods: [
      { name: "Jaggery with groundnut", name_mr: "गूळ व भुईमूग", name_hi: "गुड़ और मूंगफली" },
      { name: "Ragi bhakri", name_mr: "नाचणी भाकरी", name_hi: "रागी रोटी" },
      { name: "Spinach bhaji", name_mr: "पालक भाजी", name_hi: "पालक सब्जी" },
      { name: "Chana usal", name_mr: "चणा उसळ", name_hi: "चना उसल" },
    ],
    tip: "Add lemon juice to meals — Vitamin C helps your body absorb iron from plant foods.",
    tip_mr: "जेवणात लिंबूरस टाका — व्हिटॅमिन सी वनस्पती जन्य लोह शोषण मदत करते.",
    tip_hi: "खाने में नींबू का रस डालें — विटामिन सी पौधे जनित आयरन सोखने में मदद करता है।",
  },
  {
    nutrient: "Calcium",
    nutrient_mr: "कॅल्शियम",
    nutrient_hi: "कैल्शियम",
    foods: [
      { name: "Ragi (nachni) dishes", name_mr: "नाचणी पदार्थ", name_hi: "रागी व्यंजन" },
      { name: "Curd / buttermilk", name_mr: "दही / ताक", name_hi: "दही / छाछ" },
      { name: "Amaranth leaves", name_mr: "चौळई भाजी", name_hi: "चौलाई सब्जी" },
      { name: "Drumstick", name_mr: "शेवगा", name_hi: "सहजन" },
    ],
    tip: "Have 2 cups of milk or curd daily for strong bones and teeth.",
    tip_mr: "मजबूत हाडांसाठी दररोज २ कप दूध किंवा दही घ्या.",
    tip_hi: "मजबूत हड्डियों के लिए रोज़ २ कप दूध या दही लें।",
  },
  {
    nutrient: "Vitamin A",
    nutrient_mr: "व्हिटॅमिन ए",
    nutrient_hi: "विटामिन ए",
    foods: [
      { name: "Carrot bhaji", name_mr: "गाजर भाजी", name_hi: "गाजर सब्जी" },
      { name: "Pumpkin", name_mr: "भोपळा", name_hi: "कद्दू" },
      { name: "Mango (seasonal)", name_mr: "आंबा (हंगामी)", name_hi: "आम (मौसमी)" },
      { name: "Dark leafy greens", name_mr: "गडद हिरव्या पाने", name_hi: "गहरी हरी पत्तेदार सब्ज़ी" },
    ],
    tip: "Eat orange and dark green vegetables daily for good vision and immunity.",
    tip_mr: "दृष्टी व रोगप्रतिकारक शक्तीसाठी दररोज नारिंगी व गडद हिरव्या भाज्या खा.",
    tip_hi: "आंखों व रोग प्रतिरोधक क्षमता के लिए रोज़ नारंगी व गहरी हरी सब्ज़ी खाएं।",
  },
  {
    nutrient: "Vitamin C",
    nutrient_mr: "व्हिटॅमिन सी",
    nutrient_hi: "विटामिन सी",
    foods: [
      { name: "Guava (peru)", name_mr: "पेरू", name_hi: "अमरूद" },
      { name: "Lemon water", name_mr: "लिंबूपाणी", name_hi: "नींबू पानी" },
      { name: "Amla", name_mr: "आवळा", name_hi: "आंवला" },
      { name: "Papaya", name_mr: "पपई", name_hi: "पपीता" },
    ],
    tip: "Vitamin C helps absorb iron — squeeze lemon on dal and salads.",
    tip_mr: "व्हिटॅमिन सी लोह शोषण मदत करते — डाळीवर लिंबू टाका.",
    tip_hi: "विटामिन सी आयरन सोखने में मदद करता है — दाल पर नींबू निचोड़ें।",
  },
  {
    nutrient: "Protein",
    nutrient_mr: "प्रथिने",
    nutrient_hi: "प्रोटीन",
    foods: [
      { name: "Dal + rice combination", name_mr: "डाळ + भात", name_hi: "दाल + चावल" },
      { name: "Eggs", name_mr: "अंडी", name_hi: "अंडे" },
      { name: "Soyabean usal", name_mr: "सोयाबीन उसळ", name_hi: "सोयाबीन उसल" },
      { name: "Groundnut chutney", name_mr: "भुईमूग चटणी", name_hi: "मूंगफली चटनी" },
    ],
    tip: "Combine cereal + pulse (e.g. dal-rice) for complete protein.",
    tip_mr: "संपूर्ण प्रथिनासाठी धान्य + डाळ (उदा. डाळ-भात) एकत्र खा.",
    tip_hi: "पूर्ण प्रोटीन के लिए अनाज + दाल (जैसे दाल-चावल) साथ खाएं।",
  },
  {
    nutrient: "Fiber",
    nutrient_mr: "तंतू",
    nutrient_hi: "फाइबर",
    foods: [
      { name: "Jowar bhakri", name_mr: "ज्वारी भाकरी", name_hi: "ज्वार रोटी" },
      { name: "Whole fruits", name_mr: "संपूर्ण फळे", name_hi: "पूरे फल" },
      { name: "Leafy vegetables", name_mr: "पालेभाजी", name_hi: "पत्तेदार सब्ज़ी" },
      { name: "Sprouted pulses", name_mr: "अंकुरित कडधाने", name_hi: "अंकुरित दालें" },
    ],
    tip: "Eat whole fruits instead of juice to get the fiber your gut needs.",
    tip_mr: "रसाऐवजी संपूर्ण फळे खा — त्यात तंतू मिळतो.",
    tip_hi: "रस के बजाय पूरे फल खाएं — इससे फाइबर मिलता है।",
  },
];
