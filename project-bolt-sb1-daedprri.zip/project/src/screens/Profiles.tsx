import { useState } from "react";
import type { TranslationKey } from "../lib/translations";
import { supabase, type Profile } from "../lib/supabase";
import { Plus, Pencil, Trash2, Check, X, UserCircle } from "lucide-react";

type Props = {
  t: TranslationKey;
  profiles: Profile[];
  onProfilesChange: () => Promise<Profile[]>;
  activeProfileId: string | null;
  onSelectProfile: (id: string) => void;
};

type FormState = {
  name: string;
  age: string;
  gender: "male" | "female";
  weight_kg: string;
  height_cm: string;
  activity_level: Profile["activity_level"];
  life_stage: Profile["life_stage"];
};

const emptyForm: FormState = {
  name: "",
  age: "",
  gender: "male",
  weight_kg: "",
  height_cm: "",
  activity_level: "moderate",
  life_stage: "adult",
};

export function Profiles({ t, profiles, onProfilesChange, activeProfileId, onSelectProfile }: Props) {
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [saving, setSaving] = useState(false);

  const openAdd = () => {
    setForm(emptyForm);
    setEditingId(null);
    setShowForm(true);
  };

  const openEdit = (p: Profile) => {
    setForm({
      name: p.name,
      age: String(p.age),
      gender: p.gender,
      weight_kg: String(p.weight_kg),
      height_cm: String(p.height_cm),
      activity_level: p.activity_level,
      life_stage: p.life_stage,
    });
    setEditingId(p.id);
    setShowForm(true);
  };

  const closeForm = () => {
    setShowForm(false);
    setEditingId(null);
    setForm(emptyForm);
  };

  const handleSave = async () => {
    if (!form.name || !form.age || !form.weight_kg || !form.height_cm) return;
    setSaving(true);
    const payload = {
      name: form.name,
      age: parseInt(form.age),
      gender: form.gender,
      weight_kg: parseFloat(form.weight_kg),
      height_cm: parseFloat(form.height_cm),
      activity_level: form.activity_level,
      life_stage: form.life_stage,
    };
    if (editingId) {
      await supabase.from("profiles").update(payload).eq("id", editingId);
    } else {
      await supabase.from("profiles").insert(payload);
    }
    await onProfilesChange();
    setSaving(false);
    closeForm();
  };

  const handleDelete = async (id: string) => {
    if (!confirm(t.profiles.confirm_delete)) return;
    await supabase.from("profiles").delete().eq("id", id);
    await onProfilesChange();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="font-display font-bold text-xl text-stone-800">{t.profiles.title}</h2>
          <p className="text-sm text-stone-500 mt-1">{t.profiles.subtitle}</p>
        </div>
        <button onClick={openAdd} className="btn-primary">
          <Plus className="w-4 h-4" />
          {t.profiles.add}
        </button>
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/40 backdrop-blur-sm no-print" onClick={closeForm}>
          <div className="card w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold text-lg text-stone-800">
                {editingId ? t.profiles.edit : t.profiles.add}
              </h3>
              <button onClick={closeForm} className="text-stone-400 hover:text-stone-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="label">{t.profiles.name}</label>
                <input
                  className="input"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Gouri Patil"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="label">{t.profiles.age}</label>
                  <input
                    type="number"
                    className="input"
                    value={form.age}
                    onChange={(e) => setForm({ ...form, age: e.target.value })}
                  />
                </div>
                <div>
                  <label className="label">{t.profiles.gender}</label>
                  <select
                    className="input"
                    value={form.gender}
                    onChange={(e) => setForm({ ...form, gender: e.target.value as "male" | "female" })}
                  >
                    <option value="male">{t.profiles.male}</option>
                    <option value="female">{t.profiles.female}</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="label">{t.profiles.weight}</label>
                  <input
                    type="number"
                    className="input"
                    value={form.weight_kg}
                    onChange={(e) => setForm({ ...form, weight_kg: e.target.value })}
                  />
                </div>
                <div>
                  <label className="label">{t.profiles.height}</label>
                  <input
                    type="number"
                    className="input"
                    value={form.height_cm}
                    onChange={(e) => setForm({ ...form, height_cm: e.target.value })}
                  />
                </div>
              </div>
              <div>
                <label className="label">{t.profiles.activity}</label>
                <select
                  className="input"
                  value={form.activity_level}
                  onChange={(e) => setForm({ ...form, activity_level: e.target.value as FormState["activity_level"] })}
                >
                  <option value="sedentary">{t.profiles.sedentary}</option>
                  <option value="light">{t.profiles.light}</option>
                  <option value="moderate">{t.profiles.moderate}</option>
                  <option value="active">{t.profiles.active}</option>
                  <option value="very_active">{t.profiles.very_active}</option>
                </select>
              </div>
              <div>
                <label className="label">{t.profiles.life_stage}</label>
                <select
                  className="input"
                  value={form.life_stage}
                  onChange={(e) => setForm({ ...form, life_stage: e.target.value as FormState["life_stage"] })}
                >
                  <option value="child">{t.profiles.child}</option>
                  <option value="adolescent">{t.profiles.adolescent}</option>
                  <option value="adult">{t.profiles.adult}</option>
                  <option value="pregnant">{t.profiles.pregnant}</option>
                  <option value="lactating">{t.profiles.lactating}</option>
                  <option value="elderly">{t.profiles.elderly}</option>
                </select>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={handleSave} disabled={saving} className="btn-primary flex-1">
                {saving ? "..." : t.profiles.save}
              </button>
              <button onClick={closeForm} className="btn-ghost">
                {t.profiles.cancel}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Profile List */}
      {profiles.length === 0 ? (
        <div className="card p-12 text-center">
          <UserCircle className="w-12 h-12 text-stone-300 mx-auto mb-3" />
          <p className="text-stone-500">{t.profiles.empty}</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {profiles.map((p) => {
            const isActive = p.id === activeProfileId;
            return (
              <div
                key={p.id}
                className={`card p-5 transition-all ${
                  isActive ? "ring-2 ring-primary-500 border-primary-200" : "hover:shadow-md"
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg"
                    style={{
                      background: `hsl(${(p.name.charCodeAt(0) * 7) % 360}, 45%, 55%)`,
                    }}
                  >
                    {p.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="flex gap-1">
                    <button
                      onClick={() => openEdit(p)}
                      className="p-1.5 text-stone-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                    >
                      <Pencil className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(p.id)}
                      className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <h3 className="font-display font-semibold text-stone-800">{p.name}</h3>
                <div className="flex flex-wrap gap-1.5 mt-2">
                  <span className="chip bg-stone-100 text-stone-600">
                    {p.age}y
                  </span>
                  <span className="chip bg-stone-100 text-stone-600">
                    {p.gender === "male" ? t.profiles.male : t.profiles.female}
                  </span>
                  <span className="chip bg-stone-100 text-stone-600">
                    {p.weight_kg}kg
                  </span>
                  <span className="chip bg-primary-50 text-primary-700">
                    {t.profiles[p.life_stage as keyof TranslationKey["profiles"]] as string}
                  </span>
                </div>
                {isActive ? (
                  <div className="mt-4 flex items-center gap-2 text-primary-600 text-sm font-medium">
                    <Check className="w-4 h-4" />
                    Active
                  </div>
                ) : (
                  <button
                    onClick={() => onSelectProfile(p.id)}
                    className="mt-4 w-full btn-ghost text-sm"
                  >
                    {t.profiles.select_profile}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
