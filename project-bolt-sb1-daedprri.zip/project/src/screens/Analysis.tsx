import { useMemo } from "react";
import type { TranslationKey } from "../lib/translations";
import type { Profile, FoodRecall } from "../lib/supabase";
import { FOOD_DATABASE, getRDA } from "../lib/nutritionData";
import { AlertCircle, TrendingUp, TrendingDown, Check } from "lucide-react";

type Props = {
  t: TranslationKey;
  activeProfile: Profile | null;
  recall: FoodRecall[];
  onGoToRecall: () => void;
};

type NutrientResult = {
  key: string;
  label: string;
  intake: number;
  target: number;
  unit: string;
  percent: number;
  status: "low" | "adequate" | "high";
};

export function Analysis({ t, activeProfile, recall, onGoToRecall }: Props) {
  const results = useMemo<NutrientResult[]>(() => {
    if (!activeProfile || recall.length === 0) return [];

    // Parse quantity strings to grams
    const totalNutrients = {
      energy_kcal: 0,
      protein_g: 0,
      carbs_g: 0,
      fat_g: 0,
      fiber_g: 0,
      iron_mg: 0,
      calcium_mg: 0,
      vitamin_a_mcg: 0,
      vitamin_c_mg: 0,
    };

    for (const item of recall) {
      const food = FOOD_DATABASE.find(
        (f) =>
          f.name.toLowerCase() === item.food_name.toLowerCase() ||
          f.name_mr === item.food_name ||
          f.name_hi === item.food_name
      );
      if (!food) continue;

      const grams = parseQuantity(item.quantity, food.default_serving_g);
      const factor = grams / 100;

      totalNutrients.energy_kcal += food.energy_kcal * factor;
      totalNutrients.protein_g += food.protein_g * factor;
      totalNutrients.carbs_g += food.carbs_g * factor;
      totalNutrients.fat_g += food.fat_g * factor;
      totalNutrients.fiber_g += food.fiber_g * factor;
      totalNutrients.iron_mg += food.iron_mg * factor;
      totalNutrients.calcium_mg += food.calcium_mg * factor;
      totalNutrients.vitamin_a_mcg += food.vitamin_a_mcg * factor;
      totalNutrients.vitamin_c_mg += food.vitamin_c_mg * factor;
    }

    const rda = getRDA(
      activeProfile.life_stage,
      activeProfile.gender,
      activeProfile.age,
      activeProfile.activity_level
    );

    const build = (
      key: string,
      label: string,
      intake: number,
      target: number,
      unit: string
    ): NutrientResult => {
      const percent = target > 0 ? Math.round((intake / target) * 100) : 0;
      let status: NutrientResult["status"] = "adequate";
      if (percent < 70) status = "low";
      else if (percent > 130) status = "high";
      return { key, label, intake: Math.round(intake * 10) / 10, target, unit, percent, status };
    };

    return [
      build("energy", t.analysis.energy, totalNutrients.energy_kcal, rda.energy_kcal, "kcal"),
      build("protein", t.analysis.protein, totalNutrients.protein_g, rda.protein_g, "g"),
      build("iron", t.analysis.iron, totalNutrients.iron_mg, rda.iron_mg, "mg"),
      build("calcium", t.analysis.calcium, totalNutrients.calcium_mg, rda.calcium_mg, "mg"),
      build("vitamin_a", t.analysis.vitamin_a, totalNutrients.vitamin_a_mcg, rda.vitamin_a_mcg, "mcg"),
      build("vitamin_c", t.analysis.vitamin_c, totalNutrients.vitamin_c_mg, rda.vitamin_c_mg, "mg"),
      build("fiber", t.analysis.fiber, totalNutrients.fiber_g, rda.fiber_g, "g"),
    ];
  }, [activeProfile, recall, t]);

  if (!activeProfile || recall.length === 0) {
    return (
      <div className="card p-12 text-center">
        <AlertCircle className="w-12 h-12 text-stone-300 mx-auto mb-3" />
        <p className="text-stone-500 mb-4">{t.analysis.no_data}</p>
        <button onClick={onGoToRecall} className="btn-primary">
          {t.nav.recall}
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display font-bold text-xl text-stone-800">{t.analysis.title}</h2>
        <p className="text-sm text-stone-500 mt-1">{t.analysis.subtitle}</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {results.map((r) => {
          const barColor =
            r.status === "low"
              ? "bg-amber-400"
              : r.status === "high"
              ? "bg-red-400"
              : "bg-primary-500";
          const statusText =
            r.status === "low"
              ? t.analysis.low
              : r.status === "high"
              ? t.analysis.high
              : t.analysis.adequate;
          const StatusIcon =
            r.status === "low" ? TrendingDown : r.status === "high" ? TrendingUp : Check;
          const statusColor =
            r.status === "low"
              ? "text-amber-600 bg-amber-50"
              : r.status === "high"
              ? "text-red-600 bg-red-50"
              : "text-primary-600 bg-primary-50";

          return (
            <div key={r.key} className="card p-5">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-display font-semibold text-stone-800">{r.label}</h3>
                  <p className="text-xs text-stone-400 mt-0.5">
                    {r.intake} / {r.target} {r.unit}
                  </p>
                </div>
                <span className={`chip ${statusColor}`}>
                  <StatusIcon className="w-3 h-3" />
                  {statusText}
                </span>
              </div>

              {/* Progress Bar */}
              <div className="relative h-3 bg-stone-100 rounded-full overflow-hidden">
                <div
                  className={`absolute top-0 left-0 h-full ${barColor} rounded-full transition-all duration-500`}
                  style={{ width: `${Math.min(r.percent, 100)}%` }}
                />
              </div>
              <p className="text-xs text-stone-400 mt-2 text-right">
                {r.percent}% {t.analysis.percent_of_target}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function parseQuantity(qty: string, defaultServing: number): number {
  const num = parseFloat(qty);
  if (isNaN(num)) return defaultServing;
  if (qty.toLowerCase().includes("g")) return num;
  if (qty.toLowerCase().includes("kg")) return num * 1000;
  if (qty.toLowerCase().includes("cup")) return num * 200;
  if (qty.toLowerCase().includes("bowl")) return num * 200;
  if (qty.toLowerCase().includes("plate")) return num * 250;
  if (qty.toLowerCase().includes("pc") || qty.toLowerCase().includes("piece")) return num * 60;
  return num;
}
