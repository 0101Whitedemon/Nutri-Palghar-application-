import type { TranslationKey } from "../lib/translations";
import type { Screen } from "../App";
import type { Profile } from "../lib/supabase";
import { Users, Utensils, BarChart3, ShieldCheck, Lightbulb, CalendarDays, ArrowRight, Leaf } from "lucide-react";

type Props = {
  t: TranslationKey;
  onNavigate: (screen: Screen) => void;
  profiles: Profile[];
};

export function Home({ t, onNavigate, profiles }: Props) {
  const features: { id: Screen; icon: typeof Users; title: string; desc: string; color: string }[] = [
    { id: "profiles", icon: Users, title: t.home.feature_profiles, desc: t.home.feature_profiles_desc, color: "bg-primary-100 text-primary-700" },
    { id: "recall", icon: Utensils, title: t.home.feature_recall, desc: t.home.feature_recall_desc, color: "bg-accent-100 text-accent-700" },
    { id: "analysis", icon: BarChart3, title: t.home.feature_analysis, desc: t.home.feature_analysis_desc, color: "bg-blue-100 text-blue-700" },
    { id: "screening", icon: ShieldCheck, title: t.home.feature_screening, desc: t.home.feature_screening_desc, color: "bg-amber-100 text-amber-700" },
    { id: "advice", icon: Lightbulb, title: t.home.feature_advice, desc: t.home.feature_advice_desc, color: "bg-saffron-100 text-saffron-700" },
    { id: "planner", icon: CalendarDays, title: t.home.feature_planner, desc: t.home.feature_planner_desc, color: "bg-purple-100 text-purple-700" },
  ];

  return (
    <div className="space-y-8">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary-600 via-primary-700 to-primary-800 px-6 py-12 sm:px-12 sm:py-16">
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary-400 rounded-full filter blur-3xl opacity-20 -translate-y-1/3 translate-x-1/4"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-accent-400 rounded-full filter blur-3xl opacity-10 translate-y-1/2 -translate-x-1/4"></div>
        <div className="relative">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-3 py-1 mb-4">
            <Leaf className="w-4 h-4 text-primary-200" />
            <span className="text-xs font-medium text-primary-100">Palghar, Maharashtra</span>
          </div>
          <h2 className="font-display font-bold text-white text-2xl sm:text-4xl leading-tight max-w-xl">
            {t.home.welcome}
          </h2>
          <p className="text-primary-100 text-sm sm:text-base mt-3 max-w-lg">
            {t.home.subtitle}
          </p>
          <button
            onClick={() => onNavigate(profiles.length === 0 ? "profiles" : "recall")}
            className="mt-6 inline-flex items-center gap-2 bg-white text-primary-700 font-semibold px-5 py-2.5 rounded-xl hover:bg-primary-50 transition-all active:scale-[0.98] shadow-sm"
          >
            {t.home.get_started}
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Feature Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {features.map((f) => {
          const Icon = f.icon;
          return (
            <button
              key={f.id}
              onClick={() => onNavigate(f.id)}
              className="card p-5 text-left hover:shadow-md hover:border-stone-300 transition-all active:scale-[0.99] group"
            >
              <div className={`w-11 h-11 rounded-xl ${f.color} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                <Icon className="w-5 h-5" />
              </div>
              <h3 className="font-display font-semibold text-stone-800 text-base mb-1">
                {f.title}
              </h3>
              <p className="text-sm text-stone-500 leading-relaxed">
                {f.desc}
              </p>
            </button>
          );
        })}
      </div>
    </div>
  );
}
