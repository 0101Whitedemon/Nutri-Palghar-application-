import { useState, useEffect } from "react";
import type { TranslationKey } from "../lib/translations";
import type { Lang } from "../lib/translations";
import { supabase, type Profile, type DietPlan } from "../lib/supabase";
import { Printer, Save, Sparkles, AlertCircle } from "lucide-react";

type Props = {
  t: TranslationKey;
  lang: Lang;
  activeProfile: Profile | null;
  dietPlans: DietPlan[];
  onPlansChange: () => void;
  onGoToProfiles: () => void;
};

type DayPlan = {
  day_number: number;
  breakfast: string;
  lunch: string;
  snack: string;
  dinner: string;
  notes: string;
};

export function Planner({ t, activeProfile, dietPlans, onPlansChange, onGoToProfiles }: Props) {
  const [days, setDays] = useState<DayPlan[]>([]);
  const [saving, setSaving] = useState(false);
  const [savedMsg, setSavedMsg] = useState(false);

  useEffect(() => {
    const initial: DayPlan[] = Array.from({ length: 7 }, (_, i) => {
      const existing = dietPlans.find((d) => d.day_number === i + 1);
      return {
        day_number: i + 1,
        breakfast: existing?.breakfast || "",
        lunch: existing?.lunch || "",
        snack: existing?.snack || "",
        dinner: existing?.dinner || "",
        notes: existing?.notes || "",
      };
    });
    setDays(initial);
  }, [dietPlans]);

  if (!activeProfile) {
    return (
      <div className="card p-12 text-center">
        <AlertCircle className="w-12 h-12 text-stone-300 mx-auto mb-3" />
        <p className="text-stone-500 mb-4">{t.recall.select_profile_first}</p>
        <button onClick={onGoToProfiles} className="btn-primary">
          {t.nav.profiles}
        </button>
      </div>
    );
  }

  const dayLabels = [
    t.planner.day1, t.planner.day2, t.planner.day3, t.planner.day4,
    t.planner.day5, t.planner.day6, t.planner.day7,
  ];

  const updateDay = (idx: number, field: keyof DayPlan, value: string) => {
    setDays((prev) => prev.map((d, i) => (i === idx ? { ...d, [field]: value } : d)));
  };

  const handleSave = async () => {
    setSaving(true);
    for (const day of days) {
      const existing = dietPlans.find((d) => d.day_number === day.day_number);
      const payload = {
        profile_id: activeProfile.id,
        day_number: day.day_number,
        breakfast: day.breakfast || null,
        lunch: day.lunch || null,
        snack: day.snack || null,
        dinner: day.dinner || null,
        notes: day.notes || null,
      };
      if (existing) {
        await supabase.from("diet_plans").update(payload).eq("id", existing.id);
      } else {
        await supabase.from("diet_plans").insert(payload);
      }
    }
    await onPlansChange();
    setSaving(false);
    setSavedMsg(true);
    setTimeout(() => setSavedMsg(false), 2000);
  };

  const handleGenerate = () => {
    const breakfasts = [
      "Poha with groundnut + tea",
      "Jowar bhakri with chutney + buttermilk",
      "Ragi dosa + curd",
      "Upma with vegetables + tea",
      "Chapati with dal + milk",
      "Rice flakes with jaggery + groundnut",
      "Ragi porridge + banana",
    ];

    const lunches = [
      "Rice + toor dal + spinach bhaji + salad",
      "Jowar bhakri + chana usal + bhendi + curd",
      "Rice + moong dal + amaranth bhaji + buttermilk",
      "Chapati + soyabean usal + drumstick + salad",
      "Rice + fish curry + potato bhaji",
      "Jowar bhakri + egg curry + tomato + salad",
      "Rice + dal + carrot bhaji + curd",
    ];

    const snacks = [
      "Roasted groundnut + jaggery",
      "Guava / seasonal fruit",
      "Curd with banana",
      "Chana + lemon water",
      "Poha + tea",
      "Groundnut chutney sandwich",
      "Papaya + buttermilk",
    ];

    const dinners = [
      "Chapati + dal + leafy greens + milk",
      "Rice + dal + bhendi + curd",
      "Jowar bhakri + chicken/fish + salad",
      "Chapati + paneer bhaji + buttermilk",
      "Rice + moong dal + spinach + curd",
      "Chapati + chana curry + salad",
      "Rice + dal + drumstick + milk",
    ];

    const newDays: DayPlan[] = Array.from({ length: 7 }, (_, i) => ({
      day_number: i + 1,
      breakfast: breakfasts[i],
      lunch: lunches[i],
      snack: snacks[i],
      dinner: dinners[i],
      notes: "",
    }));

    setDays(newDays);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3 no-print">
        <div>
          <h2 className="font-display font-bold text-xl text-stone-800">{t.planner.title}</h2>
          <p className="text-sm text-stone-500 mt-1">{t.planner.subtitle}</p>
        </div>
        <div className="flex gap-2">
          <button onClick={handleGenerate} className="btn-ghost text-sm">
            <Sparkles className="w-4 h-4" />
            {t.planner.generate}
          </button>
          <button onClick={handleSave} disabled={saving} className="btn-primary text-sm">
            <Save className="w-4 h-4" />
            {saving ? "..." : t.planner.save}
          </button>
          <button onClick={() => window.print()} className="btn-accent text-sm">
            <Printer className="w-4 h-4" />
            {t.planner.print}
          </button>
        </div>
      </div>

      {savedMsg && (
        <div className="bg-primary-50 text-primary-700 rounded-xl px-4 py-2.5 text-sm font-medium no-print">
          {t.planner.saved}
        </div>
      )}

      {/* Printable Diet Chart */}
      <div className="card p-6">
        <div className="text-center mb-6 pb-4 border-b border-stone-200">
          <h3 className="font-display font-bold text-lg text-stone-800">
            {t.planner.diet_chart_for} {activeProfile.name}
          </h3>
          <p className="text-xs text-stone-400 mt-1">
            {activeProfile.age}y · {activeProfile.gender === "male" ? t.profiles.male : t.profiles.female} · {t.profiles[activeProfile.life_stage as keyof TranslationKey["profiles"]] as string}
          </p>
        </div>

        <div className="space-y-4">
          {days.map((day, idx) => (
            <div key={idx} className="border border-stone-200 rounded-xl overflow-hidden">
              <div className="bg-stone-50 px-4 py-2.5">
                <h4 className="font-display font-semibold text-stone-700 text-sm">
                  {t.planner.day} {day.day_number} — {dayLabels[idx]}
                </h4>
              </div>
              <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-stone-400 mb-1 block">
                    {t.planner.breakfast}
                  </label>
                  <textarea
                    className="input text-sm"
                    rows={2}
                    value={day.breakfast}
                    onChange={(e) => updateDay(idx, "breakfast", e.target.value)}
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-stone-400 mb-1 block">
                    {t.planner.lunch}
                  </label>
                  <textarea
                    className="input text-sm"
                    rows={2}
                    value={day.lunch}
                    onChange={(e) => updateDay(idx, "lunch", e.target.value)}
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-stone-400 mb-1 block">
                    {t.planner.snack}
                  </label>
                  <textarea
                    className="input text-sm"
                    rows={2}
                    value={day.snack}
                    onChange={(e) => updateDay(idx, "snack", e.target.value)}
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-stone-400 mb-1 block">
                    {t.planner.dinner}
                  </label>
                  <textarea
                    className="input text-sm"
                    rows={2}
                    value={day.dinner}
                    onChange={(e) => updateDay(idx, "dinner", e.target.value)}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
