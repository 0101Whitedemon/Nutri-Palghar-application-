import type { TranslationKey } from "../lib/translations";
import type { Lang } from "../lib/translations";
import { RECOMMENDATIONS } from "../lib/nutritionData";
import { Lightbulb, Utensils } from "lucide-react";

type Props = {
  t: TranslationKey;
  lang: Lang;
};

export function Advice({ t, lang }: Props) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display font-bold text-xl text-stone-800">{t.advice.title}</h2>
        <p className="text-sm text-stone-500 mt-1">{t.advice.subtitle}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {RECOMMENDATIONS.map((rec, i) => {
          const nutrientName =
            lang === "en" ? rec.nutrient : lang === "mr" ? rec.nutrient_mr : rec.nutrient_hi;
          const tip = lang === "en" ? rec.tip : lang === "mr" ? rec.tip_mr : rec.tip_hi;

          const colors = [
            "from-red-50 to-red-100 text-red-700",
            "from-blue-50 to-blue-100 text-blue-700",
            "from-amber-50 to-amber-100 text-amber-700",
            "from-green-50 to-green-100 text-green-700",
            "from-purple-50 to-purple-100 text-purple-700",
            "from-orange-50 to-orange-100 text-orange-700",
          ];
          const colorClass = colors[i % colors.length];

          return (
            <div key={i} className="card p-5 hover:shadow-md transition-shadow">
              <div className={`inline-flex items-center gap-2 rounded-lg bg-gradient-to-br ${colorClass} px-3 py-1.5 mb-4`}>
                <span className="font-display font-semibold text-sm">{nutrientName}</span>
              </div>

              <div className="mb-4">
                <p className="text-xs font-semibold text-stone-400 uppercase tracking-wide mb-2 flex items-center gap-1.5">
                  <Utensils className="w-3 h-3" />
                  {t.advice.foods}
                </p>
                <div className="space-y-1.5">
                  {rec.foods.map((food, j) => (
                    <div key={j} className="flex items-center gap-2 text-sm text-stone-600">
                      <span className="w-1.5 h-1.5 rounded-full bg-primary-400"></span>
                      {lang === "en" ? food.name : lang === "mr" ? food.name_mr : food.name_hi}
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-start gap-2 bg-stone-50 rounded-xl px-4 py-3">
                <Lightbulb className="w-4 h-4 text-saffron-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-stone-600">{tip}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
