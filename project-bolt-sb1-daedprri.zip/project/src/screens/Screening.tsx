import { useMemo } from "react";
import type { TranslationKey } from "../lib/translations";
import type { Lang } from "../lib/translations";
import type { Profile, FoodRecall } from "../lib/supabase";
import { FOOD_DATABASE, getRDA, RECOMMENDATIONS } from "../lib/nutritionData";
import { AlertCircle, ShieldCheck, AlertTriangle, Lightbulb } from "lucide-react";

type Props = {
  t: TranslationKey;
  lang: Lang;
  activeProfile: Profile | null;
  recall: FoodRecall[];
  onGoToRecall: () => void;
};

export function Screening({ t, lang, activeProfile, recall, onGoToRecall }: Props) {
  const deficiencies = useMemo(() => {
    if (!activeProfile || recall.length === 0) return [];

    const totals = {
      energy_kcal: 0,
      protein_g: 0,
      fiber_g: 0,
      iron_mg: 0,
      calcium_mg: 0,
      vitamin_a_mcg: 0,
      vitamin_c_mg: 0,
    };

    for (const item of recall) {
      const food = FOOD_DATABASE.find(
        (f) =>
          f.name.toLowerCase() === item.food_name.toLowerCase() ||
          f.name_mr === item.food_name ||
          f.name_hi === item.food_name
      );
      if (!food) continue;
      const grams = parseQuantity(item.quantity, food.default_serving_g);
      const factor = grams / 100;
      totals.energy_kcal += food.energy_kcal * factor;
      totals.protein_g += food.protein_g * factor;
      totals.fiber_g += food.fiber_g * factor;
      totals.iron_mg += food.iron_mg * factor;
      totals.calcium_mg += food.calcium_mg * factor;
      totals.vitamin_a_mcg += food.vitamin_a_mcg * factor;
      totals.vitamin_c_mg += food.vitamin_c_mg * factor;
    }

    const rda = getRDA(
      activeProfile.life_stage,
      activeProfile.gender,
      activeProfile.age,
      activeProfile.activity_level
    );

    const map: Record<string, { intake: number; target: number; nutrientKey: string }> = {
      Iron: { intake: totals.iron_mg, target: rda.iron_mg, nutrientKey: "Iron" },
      Calcium: { intake: totals.calcium_mg, target: rda.calcium_mg, nutrientKey: "Calcium" },
      "Vitamin A": { intake: totals.vitamin_a_mcg, target: rda.vitamin_a_mcg, nutrientKey: "Vitamin A" },
      "Vitamin C": { intake: totals.vitamin_c_mg, target: rda.vitamin_c_mg, nutrientKey: "Vitamin C" },
      Protein: { intake: totals.protein_g, target: rda.protein_g, nutrientKey: "Protein" },
      Fiber: { intake: totals.fiber_g, target: rda.fiber_g, nutrientKey: "Fiber" },
    };

    const result: typeof RECOMMENDATIONS = [];
    for (const rec of RECOMMENDATIONS) {
      const data = map[rec.nutrient];
      if (data && data.target > 0 && data.intake / data.target < 0.7) {
        result.push(rec);
      }
    }
    return result;
  }, [activeProfile, recall]);

  if (!activeProfile || recall.length === 0) {
    return (
      <div className="card p-12 text-center">
        <AlertCircle className="w-12 h-12 text-stone-300 mx-auto mb-3" />
        <p className="text-stone-500 mb-4">{t.screening.no_data}</p>
        <button onClick={onGoToRecall} className="btn-primary">
          {t.nav.recall}
        </button>
      </div>
    );
  }

  if (deficiencies.length === 0) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="font-display font-bold text-xl text-stone-800">{t.screening.title}</h2>
          <p className="text-sm text-stone-500 mt-1">{t.screening.subtitle}</p>
        </div>
        <div className="card p-12 text-center">
          <ShieldCheck className="w-14 h-14 text-primary-500 mx-auto mb-4" />
          <p className="text-primary-700 font-medium text-lg">{t.screening.no_deficiency}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display font-bold text-xl text-stone-800">{t.screening.title}</h2>
        <p className="text-sm text-stone-500 mt-1">{t.screening.subtitle}</p>
      </div>

      <div className="flex items-center gap-2 bg-amber-50 text-amber-700 rounded-xl px-4 py-3 text-sm">
        <AlertTriangle className="w-5 h-5 flex-shrink-0" />
        <span>{t.screening.at_risk}: {deficiencies.length}</span>
      </div>

      <div className="space-y-4">
        {deficiencies.map((rec, i) => {
          const nutrientName =
            lang === "en" ? rec.nutrient : lang === "mr" ? rec.nutrient_mr : rec.nutrient_hi;
          const tip = lang === "en" ? rec.tip : lang === "mr" ? rec.tip_mr : rec.tip_hi;

          return (
            <div key={i} className="card p-5">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <h3 className="font-display font-semibold text-stone-800">{nutrientName}</h3>
                  <p className="text-xs text-stone-400">{t.screening.recommendation}</p>
                </div>
              </div>

              {/* Foods to eat */}
              <div className="mb-4">
                <p className="text-xs font-semibold text-stone-400 uppercase tracking-wide mb-2">
                  {t.screening.foods_to_eat}
                </p>
                <div className="flex flex-wrap gap-2">
                  {rec.foods.map((food, j) => (
                    <span key={j} className="chip bg-primary-50 text-primary-700 border border-primary-100">
                      {lang === "en" ? food.name : lang === "mr" ? food.name_mr : food.name_hi}
                    </span>
                  ))}
                </div>
              </div>

              {/* Tip */}
              <div className="flex items-start gap-2 bg-saffron-50 rounded-xl px-4 py-3">
                <Lightbulb className="w-4 h-4 text-saffron-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-saffron-800">{tip}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function parseQuantity(qty: string, defaultServing: number): number {
  const num = parseFloat(qty);
  if (isNaN(num)) return defaultServing;
  if (qty.toLowerCase().includes("g")) return num;
  if (qty.toLowerCase().includes("kg")) return num * 1000;
  if (qty.toLowerCase().includes("cup")) return num * 200;
  if (qty.toLowerCase().includes("bowl")) return num * 200;
  if (qty.toLowerCase().includes("plate")) return num * 250;
  if (qty.toLowerCase().includes("pc") || qty.toLowerCase().includes("piece")) return num * 60;
  return num;
}
