import { useState, useMemo } from "react";
import type { TranslationKey } from "../lib/translations";
import type { Lang } from "../lib/translations";
import { supabase, type Profile, type FoodRecall } from "../lib/supabase";
import { FOOD_DATABASE, type FoodItem } from "../lib/nutritionData";
import { Search, Plus, Trash2, Utensils, AlertCircle } from "lucide-react";

type Props = {
  t: TranslationKey;
  lang: Lang;
  activeProfile: Profile | null;
  recall: FoodRecall[];
  onRecallChange: () => void;
  onGoToProfiles: () => void;
};

export function FoodRecallScreen({ t, lang, activeProfile, recall, onRecallChange, onGoToProfiles }: Props) {
  const [search, setSearch] = useState("");
  const [selectedFood, setSelectedFood] = useState<FoodItem | null>(null);
  const [mealType, setMealType] = useState<FoodRecall["meal_type"]>("breakfast");
  const [quantity, setQuantity] = useState("");
  const [adding, setAdding] = useState(false);

  const searchResults = useMemo(() => {
    if (!search.trim()) return [];
    const q = search.toLowerCase();
    return FOOD_DATABASE.filter(
      (f) =>
        f.name.toLowerCase().includes(q) ||
        f.name_mr.includes(search) ||
        f.name_hi.includes(search)
    ).slice(0, 8);
  }, [search]);

  const handleAdd = async () => {
    if (!activeProfile || !selectedFood || !quantity) return;
    setAdding(true);
    await supabase.from("food_recall").insert({
      profile_id: activeProfile.id,
      food_name: selectedFood.name,
      meal_type: mealType,
      quantity: quantity,
      recall_date: new Date().toISOString().split("T")[0],
    });
    setAdding(false);
    setSelectedFood(null);
    setQuantity("");
    setSearch("");
    onRecallChange();
  };

  const handleRemove = async (id: string) => {
    await supabase.from("food_recall").delete().eq("id", id);
    onRecallChange();
  };

  if (!activeProfile) {
    return (
      <div className="card p-12 text-center">
        <AlertCircle className="w-12 h-12 text-stone-300 mx-auto mb-3" />
        <p className="text-stone-500 mb-4">{t.recall.select_profile_first}</p>
        <button onClick={onGoToProfiles} className="btn-primary">
          {t.nav.profiles}
        </button>
      </div>
    );
  }

  const mealTypes: { id: FoodRecall["meal_type"]; label: string }[] = [
    { id: "breakfast", label: t.recall.breakfast },
    { id: "lunch", label: t.recall.lunch },
    { id: "snack", label: t.recall.snack },
    { id: "dinner", label: t.recall.dinner },
  ];

  const groupedRecall = mealTypes.map((m) => ({
    ...m,
    items: recall.filter((r) => r.meal_type === m.id),
  }));

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display font-bold text-xl text-stone-800">{t.recall.title}</h2>
        <p className="text-sm text-stone-500 mt-1">{t.recall.subtitle}</p>
      </div>

      {/* Quick Add */}
      <div className="card p-5">
        <h3 className="font-display font-semibold text-stone-700 mb-3 flex items-center gap-2">
          <Plus className="w-4 h-4 text-primary-600" />
          {t.recall.quick_add}
        </h3>

        {/* Search */}
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
          <input
            className="input pl-10"
            placeholder={t.recall.search_placeholder}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          {searchResults.length > 0 && (
            <div className="absolute z-10 mt-1 w-full card max-h-60 overflow-y-auto shadow-lg">
              {searchResults.map((f) => (
                <button
                  key={f.id}
                  onClick={() => {
                    setSelectedFood(f);
                    setQuantity(`${f.default_serving_g}g`);
                    setSearch(f.name);
                  }}
                  className="w-full text-left px-4 py-2.5 hover:bg-primary-50 transition-colors border-b border-stone-100 last:border-0"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-sm font-medium text-stone-700">
                        {lang === "en" ? f.name : lang === "mr" ? f.name_mr : f.name_hi}
                      </span>
                      <span className="text-xs text-stone-400 ml-2">
                        {f.energy_kcal} kcal / 100g
                      </span>
                    </div>
                    <span className="text-xs text-stone-400 capitalize">{f.category}</span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Selected food + meal + quantity */}
        {selectedFood && (
          <div className="bg-primary-50 rounded-xl p-3 mb-3 flex items-center justify-between">
            <span className="text-sm font-medium text-primary-800">
              {lang === "en" ? selectedFood.name : lang === "mr" ? selectedFood.name_mr : selectedFood.name_hi}
            </span>
            <button
              onClick={() => setSelectedFood(null)}
              className="text-stone-400 hover:text-stone-600"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <select
            className="input"
            value={mealType}
            onChange={(e) => setMealType(e.target.value as FoodRecall["meal_type"])}
          >
            {mealTypes.map((m) => (
              <option key={m.id} value={m.id}>
                {m.label}
              </option>
            ))}
          </select>
          <input
            className="input"
            placeholder={t.recall.quantity}
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
          />
          <button
            onClick={handleAdd}
            disabled={!selectedFood || !quantity || adding}
            className="btn-primary"
          >
            {adding ? "..." : t.recall.add}
          </button>
        </div>
      </div>

      {/* Recall Summary */}
      <div className="card p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display font-semibold text-stone-700 flex items-center gap-2">
            <Utensils className="w-4 h-4 text-accent-600" />
            {t.recall.total_items}: {recall.length}
          </h3>
        </div>

        {recall.length === 0 ? (
          <p className="text-stone-400 text-sm text-center py-8">{t.recall.empty}</p>
        ) : (
          <div className="space-y-4">
            {groupedRecall.map((group) => {
              if (group.items.length === 0) return null;
              return (
                <div key={group.id}>
                  <h4 className="text-xs font-semibold text-stone-400 uppercase tracking-wide mb-2">
                    {group.label}
                  </h4>
                  <div className="space-y-2">
                    {group.items.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between bg-stone-50 rounded-xl px-4 py-2.5"
                      >
                        <div>
                          <span className="text-sm font-medium text-stone-700">
                            {item.food_name}
                          </span>
                          <span className="text-xs text-stone-400 ml-2">
                            {item.quantity}
                          </span>
                        </div>
                        <button
                          onClick={() => handleRemove(item.id)}
                          className="p-1 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
