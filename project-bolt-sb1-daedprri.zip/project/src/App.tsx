import { useState, useEffect, useCallback } from "react";
import { supabase, type Profile, type FoodRecall, type DietPlan } from "./lib/supabase";
import { translations, type Lang } from "./lib/translations";
import { Home } from "./screens/Home";
import { Profiles } from "./screens/Profiles";
import { FoodRecallScreen } from "./screens/FoodRecallScreen";
import { Analysis } from "./screens/Analysis";
import { Screening } from "./screens/Screening";
import { Advice } from "./screens/Advice";
import { Planner } from "./screens/Planner";
import { Home as HomeIcon, Users, Utensils, BarChart3, ShieldCheck, Lightbulb, CalendarDays } from "lucide-react";

export type Screen =
  | "home"
  | "profiles"
  | "recall"
  | "analysis"
  | "screening"
  | "advice"
  | "planner";

export default function App() {
  const [lang, setLang] = useState<Lang>("en");
  const [screen, setScreen] = useState<Screen>("home");
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [activeProfileId, setActiveProfileId] = useState<string | null>(null);
  const [recall, setRecall] = useState<FoodRecall[]>([]);
  const [dietPlans, setDietPlans] = useState<DietPlan[]>([]);
  const [loading, setLoading] = useState(true);

  const t = translations[lang];

  const loadProfiles = useCallback(async () => {
    const { data } = await supabase.from("profiles").select("*").order("created_at");
    if (data) setProfiles(data as Profile[]);
    return data as Profile[];
  }, []);

  const loadRecall = useCallback(async (profileId: string) => {
    const { data } = await supabase
      .from("food_recall")
      .select("*")
      .eq("profile_id", profileId)
      .order("recall_date", { ascending: false });
    if (data) setRecall(data as FoodRecall[]);
  }, []);

  const loadDietPlans = useCallback(async (profileId: string) => {
    const { data } = await supabase
      .from("diet_plans")
      .select("*")
      .eq("profile_id", profileId)
      .order("day_number", { ascending: true });
    if (data) setDietPlans(data as DietPlan[]);
  }, []);

  useEffect(() => {
    (async () => {
      await loadProfiles();
      setLoading(false);
    })();
  }, [loadProfiles]);

  const selectProfile = useCallback(
    (id: string) => {
      setActiveProfileId(id);
      loadRecall(id);
      loadDietPlans(id);
    },
    [loadRecall, loadDietPlans]
  );

  const navItems: { id: Screen; icon: typeof HomeIcon; label: string }[] = [
    { id: "home", icon: HomeIcon, label: t.nav.home },
    { id: "profiles", icon: Users, label: t.nav.profiles },
    { id: "recall", icon: Utensils, label: t.nav.recall },
    { id: "analysis", icon: BarChart3, label: t.nav.analysis },
    { id: "screening", icon: ShieldCheck, label: t.nav.screening },
    { id: "advice", icon: Lightbulb, label: t.nav.advice },
    { id: "planner", icon: CalendarDays, label: t.nav.planner },
  ];

  const activeProfile = profiles.find((p) => p.id === activeProfileId) || null;

  return (
    <div className="min-h-screen bg-stone-50">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-stone-200 no-print">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16">
            <button
              onClick={() => setScreen("home")}
              className="flex items-center gap-2.5 group"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform">
                <span className="text-white font-display font-bold text-lg">N</span>
              </div>
              <div className="text-left">
                <h1 className="font-display font-bold text-stone-800 text-base leading-tight">
                  {t.app_name}
                </h1>
                <p className="text-[10px] text-stone-400 leading-tight hidden sm:block">
                  {t.tagline}
                </p>
              </div>
            </button>

            <div className="flex items-center gap-2">
              {/* Language Switcher */}
              <div className="flex items-center gap-1 bg-stone-100 rounded-lg p-1">
                {(["en", "mr", "hi"] as Lang[]).map((l) => (
                  <button
                    key={l}
                    onClick={() => setLang(l)}
                    className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all ${
                      lang === l
                        ? "bg-white text-primary-700 shadow-sm"
                        : "text-stone-500 hover:text-stone-700"
                    }`}
                  >
                    {l === "en" ? "EN" : l === "mr" ? "मराठी" : "हिं"}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="border-t border-stone-100">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="flex items-center gap-1 overflow-x-auto scrollbar-hide">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = screen === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setScreen(item.id)}
                    className={`flex items-center gap-2 px-3.5 py-3 text-sm font-medium whitespace-nowrap border-b-2 transition-all ${
                      isActive
                        ? "border-primary-600 text-primary-700"
                        : "border-transparent text-stone-500 hover:text-stone-700"
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span className="hidden sm:inline">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </nav>
      </header>

      {/* Active Profile Banner */}
      {activeProfile && screen !== "home" && screen !== "profiles" && (
        <div className="bg-primary-50 border-b border-primary-100 no-print">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 py-2 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-primary-600 flex items-center justify-center">
                <span className="text-white text-xs font-bold">
                  {activeProfile.name.charAt(0).toUpperCase()}
                </span>
              </div>
              <span className="text-sm font-medium text-primary-800">
                {activeProfile.name}
              </span>
              <span className="text-xs text-primary-600">
                · {activeProfile.age}y · {activeProfile.gender === "male" ? t.profiles.male : t.profiles.female}
              </span>
            </div>
            <button
              onClick={() => setScreen("profiles")}
              className="text-xs font-medium text-primary-700 hover:underline"
            >
              {t.profiles.select_profile}
            </button>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-3 border-primary-200 border-t-primary-600 rounded-full animate-spin"></div>
          </div>
        ) : (
          <>
            {screen === "home" && (
              <Home t={t} onNavigate={setScreen} profiles={profiles} />
            )}
            {screen === "profiles" && (
              <Profiles
                t={t}
                profiles={profiles}
                onProfilesChange={loadProfiles}
                activeProfileId={activeProfileId}
                onSelectProfile={selectProfile}
              />
            )}
            {screen === "recall" && (
              <FoodRecallScreen
                t={t}
                lang={lang}
                activeProfile={activeProfile}
                recall={recall}
                onRecallChange={() => activeProfileId && loadRecall(activeProfileId)}
                onGoToProfiles={() => setScreen("profiles")}
              />
            )}
            {screen === "analysis" && (
              <Analysis
                t={t}
                activeProfile={activeProfile}
                recall={recall}
                onGoToRecall={() => setScreen("recall")}
              />
            )}
            {screen === "screening" && (
              <Screening
                t={t}
                lang={lang}
                activeProfile={activeProfile}
                recall={recall}
                onGoToRecall={() => setScreen("recall")}
              />
            )}
            {screen === "advice" && <Advice t={t} lang={lang} />}
            {screen === "planner" && (
              <Planner
                t={t}
                lang={lang}
                activeProfile={activeProfile}
                dietPlans={dietPlans}
                onPlansChange={() => activeProfileId && loadDietPlans(activeProfileId)}
                onGoToProfiles={() => setScreen("profiles")}
              />
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-stone-200 mt-12 no-print">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 text-center">
          <p className="text-xs text-stone-400">
            {t.app_name} · {t.tagline}
          </p>
        </div>
      </footer>
    </div>
  );
}
